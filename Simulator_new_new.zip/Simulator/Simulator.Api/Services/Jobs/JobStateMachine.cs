using Simulator.Api.Models;

namespace Simulator.Api.Services.Jobs;

public interface IJobStateMachine
{
    bool CanTransition(JobStatus from, JobStatus to);

    /// <summary>Moves the job to <paramref name="to"/> or throws <see cref="InvalidJobStateException"/>.</summary>
    void Transition(SimulationJob job, JobStatus to, string? reason = null);

    /// <summary>Moves the job to <paramref name="to"/> if allowed; returns false otherwise.</summary>
    bool TryTransition(SimulationJob job, JobStatus to, string? reason = null);
}

/// <summary>
/// Single place that decides which status changes are allowed and what happens on each change.
///
///   Received  -> Running | Stopped
///   Running   -> Stopping | Completed | Failed
///   Stopping  -> Stopped | Failed
///   Stopped   -> Running            (restart)
///   Completed -> Running            (run again)
///   Failed    -> Running            (retry)
/// </summary>
public sealed class JobStateMachine(TimeProvider time, ILogger<JobStateMachine> logger) : IJobStateMachine
{
    private static readonly Dictionary<JobStatus, JobStatus[]> AllowedTransitions = new()
    {
        [JobStatus.Received] = [JobStatus.Running, JobStatus.Stopped],
        [JobStatus.Running] = [JobStatus.Stopping, JobStatus.Completed, JobStatus.Failed],
        [JobStatus.Stopping] = [JobStatus.Stopped, JobStatus.Failed],
        [JobStatus.Stopped] = [JobStatus.Running],
        [JobStatus.Completed] = [JobStatus.Running],
        [JobStatus.Failed] = [JobStatus.Running],
    };

    public bool CanTransition(JobStatus from, JobStatus to) =>
        AllowedTransitions.TryGetValue(from, out var targets) && targets.Contains(to);

    public void Transition(SimulationJob job, JobStatus to, string? reason = null)
    {
        lock (job.SyncRoot)
        {
            if (!TryTransition(job, to, reason))
                throw new InvalidJobStateException(job.Id, job.Status,
                    $"Job cannot move from {job.Status} to {to}.");
        }
    }

    public bool TryTransition(SimulationJob job, JobStatus to, string? reason = null)
    {
        lock (job.SyncRoot)
        {
            var from = job.Status;
            if (!CanTransition(from, to)) return false;

            var now = time.GetUtcNow();
            ApplyEntryActions(job, to, now, reason);
            job.Status = to;
            job.AddHistory(new JobStatusChange(from, to, now, reason));

            logger.LogInformation("Job {JobId}: {From} -> {To} ({Reason})", job.Id, from, to, reason ?? "-");
            return true;
        }
    }

    private static void ApplyEntryActions(SimulationJob job, JobStatus to, DateTimeOffset now, string? reason)
    {
        switch (to)
        {
            case JobStatus.Running:
                job.RunCount++;
                job.StartedAt = now;
                job.EndedAt = null;
                job.ErrorMessage = null;
                job.ResetProgress();
                break;

            case JobStatus.Stopped:
            case JobStatus.Completed:
                job.EndedAt = now;
                break;

            case JobStatus.Failed:
                job.EndedAt = now;
                job.ErrorMessage = reason;
                break;
        }
    }
}
