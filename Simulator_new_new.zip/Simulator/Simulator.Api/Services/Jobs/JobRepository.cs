using System.Collections.Concurrent;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Jobs;

public interface IJobRepository
{
    void Add(SimulationJob job);
    SimulationJob? Get(Guid id);
    IReadOnlyCollection<SimulationJob> GetAll();
}

/// <summary>
/// In-memory job registry. Jobs are lost when the service restarts; swap this for a
/// database-backed implementation if jobs need to survive restarts.
/// </summary>
public sealed class InMemoryJobRepository : IJobRepository
{
    private readonly ConcurrentDictionary<Guid, SimulationJob> _jobs = new();

    public void Add(SimulationJob job)
    {
        if (!_jobs.TryAdd(job.Id, job))
            throw new InvalidOperationException($"A job with id '{job.Id}' is already registered.");
    }

    public SimulationJob? Get(Guid id) => _jobs.GetValueOrDefault(id);

    public IReadOnlyCollection<SimulationJob> GetAll() =>
        _jobs.Values.OrderByDescending(j => j.ReceivedAt).ToList();
}
