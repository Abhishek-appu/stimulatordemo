using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using Simulator.Api.Configuration;

namespace Simulator.Api.Infrastructure;

public static class JwtAuthenticationExtensions
{
    /// <summary>
    /// Registers JWT bearer validation and makes it the default policy for [Authorize].
    /// Invalid settings stop the app at startup with a clear message.
    /// </summary>
    public static IServiceCollection AddJwtValidation(this IServiceCollection services, IConfiguration configuration)
    {
        var options = configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>() ?? new JwtOptions();
        services.Configure<JwtOptions>(configuration.GetSection(JwtOptions.SectionName));

        if (!options.Enabled)
        {
            // [Authorize] still works but lets everyone through.
            services.AddAuthentication();
            services.AddAuthorization(a => a.DefaultPolicy = new AuthorizationPolicyBuilder().RequireAssertion(_ => true).Build());
            return services;
        }

        ValidateSettings(options);

        services
            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(jwt =>
            {
                // Keep claim names as they are in the token ("sub", "scp", "roles"...).
                jwt.MapInboundClaims = false;

                jwt.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = options.Audience,
                    ValidateLifetime = true,
                    RequireExpirationTime = true,
                    RequireSignedTokens = true,
                    ValidateIssuerSigningKey = true,
                    ClockSkew = TimeSpan.FromSeconds(options.ClockSkewSeconds),
                    NameClaimType = "name",
                    RoleClaimType = "roles",
                };

                if (options.UsesAuthority)
                {
                    jwt.Authority = options.Authority;
                    jwt.Audience = options.Audience;
                    jwt.RequireHttpsMetadata = options.RequireHttpsMetadata;
                    if (!string.IsNullOrWhiteSpace(options.Issuer))
                        jwt.TokenValidationParameters.ValidIssuer = options.Issuer;
                }
                else
                {
                    jwt.TokenValidationParameters.ValidIssuer = options.Issuer;
                    jwt.TokenValidationParameters.IssuerSigningKey = CreateSigningKey(options.SigningKey!);
                    jwt.TokenValidationParameters.ValidAlgorithms = [SecurityAlgorithms.HmacSha256];
                }

                jwt.Events = new JwtBearerEvents
                {
                    OnAuthenticationFailed = context =>
                    {
                        context.HttpContext.RequestServices.GetRequiredService<ILoggerFactory>()
                            .CreateLogger("Simulator.Api.Jwt")
                            .LogInformation("Rejected token: {Reason}", context.Exception.Message);
                        return Task.CompletedTask;
                    }
                };
            });

        services.AddAuthorization(a =>
        {
            var policy = new AuthorizationPolicyBuilder(JwtBearerDefaults.AuthenticationScheme).RequireAuthenticatedUser();

            if (!string.IsNullOrWhiteSpace(options.RequiredScope))
                policy.RequireAssertion(ctx => HasValue(ctx.User, options.RequiredScope, "scp", "scope"));

            if (!string.IsNullOrWhiteSpace(options.RequiredRole))
                policy.RequireAssertion(ctx => HasValue(ctx.User, options.RequiredRole, "roles", "role", ClaimTypes.Role));

            a.DefaultPolicy = policy.Build();
        });

        return services;
    }

    /// <summary>
    /// POST /dev/token - creates a test token signed with the configured key.
    /// Only mapped in Development, in signing-key mode, when Jwt:EnableDevTokenEndpoint is true.
    /// </summary>
    public static void MapDevTokenEndpoint(this WebApplication app)
    {
        var options = app.Configuration.GetSection(JwtOptions.SectionName).Get<JwtOptions>() ?? new JwtOptions();
        if (!app.Environment.IsDevelopment() || !options.Enabled || !options.UsesSigningKey || !options.EnableDevTokenEndpoint)
            return;

        app.MapPost("/dev/token", (DevTokenRequest? request) =>
        {
            var now = DateTime.UtcNow;
            var minutes = Math.Clamp(request?.ExpiresInMinutes ?? 60, 1, 24 * 60);
            var claims = new Dictionary<string, object>
            {
                ["sub"] = request?.Subject ?? "dev-user",
                ["name"] = request?.Subject ?? "dev-user",
            };
            if (request?.Roles is { Length: > 0 } roles) claims["roles"] = roles;
            if (!string.IsNullOrWhiteSpace(request?.Scope)) claims["scp"] = request.Scope;

            var token = new JsonWebTokenHandler().CreateToken(new SecurityTokenDescriptor
            {
                Issuer = options.Issuer,
                Audience = options.Audience,
                IssuedAt = now,
                NotBefore = now,
                Expires = now.AddMinutes(minutes),
                Claims = claims,
                SigningCredentials = new SigningCredentials(CreateSigningKey(options.SigningKey!), SecurityAlgorithms.HmacSha256),
            });

            return Results.Ok(new { access_token = token, token_type = "Bearer", expires_in = minutes * 60 });
        })
        .AllowAnonymous()
        .WithTags("Development");

        app.Logger.LogWarning("POST /dev/token is enabled. It must never be enabled outside local development.");
    }

    private static void ValidateSettings(JwtOptions o)
    {
        var problems = new List<string>();

        if (o.UsesAuthority == o.UsesSigningKey)
            problems.Add("set either Jwt:Authority (identity provider) or Jwt:SigningKey (own HS256 key), not both and not neither");
        if (string.IsNullOrWhiteSpace(o.Audience))
            problems.Add("Jwt:Audience is required");
        if (o.UsesAuthority && !Uri.TryCreate(o.Authority, UriKind.Absolute, out _))
            problems.Add($"Jwt:Authority '{o.Authority}' is not a valid URL");
        if (o.UsesSigningKey && string.IsNullOrWhiteSpace(o.Issuer))
            problems.Add("Jwt:Issuer is required when Jwt:SigningKey is used");
        if (o.UsesSigningKey && Encoding.UTF8.GetByteCount(o.SigningKey!) < 32)
            problems.Add("Jwt:SigningKey must be at least 32 characters (256 bits) for HS256");
        if (o.ClockSkewSeconds < 0)
            problems.Add("Jwt:ClockSkewSeconds cannot be negative");

        if (problems.Count > 0)
            throw new InvalidOperationException("Invalid JWT settings: " + string.Join("; ", problems) +
                                                ". Set Jwt:Enabled to false to run without authentication.");
    }

    private static SymmetricSecurityKey CreateSigningKey(string key) => new(Encoding.UTF8.GetBytes(key));

    /// <summary>Claim may hold one value, a space-separated list (scopes) or repeat (roles).</summary>
    private static bool HasValue(ClaimsPrincipal user, string required, params string[] claimTypes) =>
        user.Claims
            .Where(c => claimTypes.Contains(c.Type))
            .SelectMany(c => c.Value.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            .Contains(required, StringComparer.Ordinal);

    private sealed record DevTokenRequest(string? Subject, string[]? Roles, string? Scope, int? ExpiresInMinutes);
}
