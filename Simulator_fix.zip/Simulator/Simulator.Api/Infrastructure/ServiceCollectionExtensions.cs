using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Services.Jobs;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Services.Storage;
using Simulator.Api.Services.Stores;
using Simulator.Api.Validation;

namespace Simulator.Api.Infrastructure;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddSimulator(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddSingleton(TimeProvider.System);

        services.AddOptions<JobStorageOptions>().Bind(configuration.GetSection(JobStorageOptions.SectionName))
            .Validate(o => o.MaxFileSizeMb > 0 && !string.IsNullOrWhiteSpace(o.StoragePath), "Invalid JobStorage settings.")
            .ValidateOnStart();
        services.AddOptions<SimulationOptions>().Bind(configuration.GetSection(SimulationOptions.SectionName))
            .Validate(o => o.DepthRowIntervalMs >= 0 && o.MaxRowDelayMs >= 0 && o.MaxLoopCount >= 1 && o.StopWaitTimeoutSeconds >= 0
                      && o.EffectiveSpeeds.All(speed => speed >= 1),
                "Invalid Simulation settings.")
            .ValidateOnStart();

        // File parsers
        services.AddSingleton<ILogFileParser, CsvLogParser>();
        services.AddSingleton<ILogFileParser, LasLogParser>();
        services.AddSingleton<ILogFileParser, WitsmlLogParser>();
        services.AddSingleton<ILogFileParserResolver, LogFileParserResolver>();

        // Upload: validation (format, structure, log type) + registration/storage
        services.AddSingleton<IFileValidator, FileValidator>();
        services.AddSingleton<IJobFileStorage, LocalJobFileStorage>();
        services.AddSingleton<IJobRepository, FileJobRepository>();
        services.AddHostedService<JobStartupLoader>();   // loads saved jobs before requests are served

        // Start / stop job: state machine, background runner, executor
        services.AddSingleton<IJobStateMachine, JobStateMachine>();
        services.AddSingleton<JobRunner>();
        services.AddSingleton<IJobRunner>(sp => sp.GetRequiredService<JobRunner>());
        services.AddHostedService(sp => sp.GetRequiredService<JobRunner>());
        services.AddScoped<IJobExecutor, JobExecutor>();
        services.AddSingleton<IJobService, JobService>();

        AddStores(services, configuration);
        return services;
    }

    private static void AddStores(IServiceCollection services, IConfiguration configuration)
    {
        var useSimulated = configuration.GetValue<bool>($"{SimulationOptions.SectionName}:{nameof(SimulationOptions.UseSimulatedStores)}");
        if (useSimulated)
        {
            services.AddSingleton<IProductStoreClient, SimulatedProductStoreClient>();
            services.AddSingleton<IDataStoreClient, SimulatedDataStoreClient>();
            return;
        }

        services.Configure<ProductStoreOptions>(configuration.GetSection(ProductStoreOptions.SectionName));
        services.Configure<DataStoreOptions>(configuration.GetSection(DataStoreOptions.SectionName));

        // One Bearer token, shared by both stores (OAuth2 client credentials).
        var auth = configuration.GetSection(StoreAuthOptions.SectionName).Get<StoreAuthOptions>() ?? new StoreAuthOptions();
        ValidateStoreAuth(auth);
        services.Configure<StoreAuthOptions>(configuration.GetSection(StoreAuthOptions.SectionName));
        services.AddHttpClient(StoreTokenProvider.TokenClientName, http => http.Timeout = TimeSpan.FromSeconds(auth.TimeoutSeconds));
        services.AddSingleton<IStoreTokenProvider, StoreTokenProvider>();
        services.AddTransient<StoreBearerTokenHandler>();

        services.AddHttpClient<IProductStoreClient, ProductStoreClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<ProductStoreOptions>>().Value;
            ConfigureClient(http, "ProductStore", o.BaseUrl, o.TimeoutSeconds);
        }).AddHttpMessageHandler<StoreBearerTokenHandler>();

        services.AddHttpClient<IDataStoreClient, DataStoreClient>((sp, http) =>
        {
            var o = sp.GetRequiredService<IOptions<DataStoreOptions>>().Value;
            ConfigureClient(http, "DataStore", o.BaseUrl, o.TimeoutSeconds);
        }).AddHttpMessageHandler<StoreBearerTokenHandler>();
    }

    /// <summary>Stops the app at startup if the store token settings are incomplete.</summary>
    private static void ValidateStoreAuth(StoreAuthOptions o)
    {
        var problems = new List<string>();
        switch (o.Mode)
        {
            case StoreAuthMode.ClientCredentials:
                if (!Uri.TryCreate(o.TokenEndpoint, UriKind.Absolute, out _)) problems.Add("StoreAuth:TokenEndpoint must be a valid URL");
                if (string.IsNullOrWhiteSpace(o.ClientId)) problems.Add("StoreAuth:ClientId is required");
                if (string.IsNullOrWhiteSpace(o.ClientSecret)) problems.Add("StoreAuth:ClientSecret is required");
                break;
            case StoreAuthMode.StaticToken:
                if (string.IsNullOrWhiteSpace(o.StaticToken)) problems.Add("StoreAuth:StaticToken is required");
                break;
        }
        if (o.RefreshBeforeExpirySeconds < 0) problems.Add("StoreAuth:RefreshBeforeExpirySeconds cannot be negative");

        if (problems.Count > 0)
            throw new InvalidOperationException("Invalid StoreAuth settings: " + string.Join("; ", problems) +
                ". Or set Simulation:UseSimulatedStores to true to run without the real stores.");
    }

    private static void ConfigureClient(HttpClient http, string name, string baseUrl, int timeoutSeconds)
    {
        if (!Uri.TryCreate(baseUrl, UriKind.Absolute, out var uri))
            throw new InvalidOperationException($"{name}:BaseUrl '{baseUrl}' is not a valid absolute URL.");

        // Trailing slash so relative paths like "api/wells" append to any base path.
        http.BaseAddress = uri.AbsoluteUri.EndsWith('/') ? uri : new Uri(uri.AbsoluteUri + "/");
        http.Timeout = TimeSpan.FromSeconds(timeoutSeconds);
    }
}
