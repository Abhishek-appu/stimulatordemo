namespace Simulator.Api.Models;

/// <summary>Supported upload formats.</summary>
public enum FileFormat
{
    Csv,
    Las,
    Witsml
}

/// <summary>How rows in the log are indexed.</summary>
public enum LogType
{
    Unknown,
    Time,
    Depth
}

/// <summary>
/// Lifecycle of a simulation job. Allowed moves are defined in <see cref="Services.Jobs.JobStateMachine"/>.
/// </summary>
public enum JobStatus
{
    /// <summary>File uploaded, validated and stored. Waiting for the user to pick a speed and start.</summary>
    Received,

    /// <summary>Header sent to the product store; data is being streamed to the data store.</summary>
    Running,

    /// <summary>Stop requested; waiting for the running execution to cancel.</summary>
    Stopping,

    /// <summary>Stopped by a user (or by shutdown) before finishing.</summary>
    Stopped,

    /// <summary>All rows for all loops were sent.</summary>
    Completed,

    /// <summary>Execution ended with an error.</summary>
    Failed
}
