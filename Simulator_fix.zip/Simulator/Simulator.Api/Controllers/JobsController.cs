using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Contracts;
using Simulator.Api.Models;
using Simulator.Api.Services.Jobs;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Validation;

namespace Simulator.Api.Controllers;

/// <summary>
/// Flow:
/// 1. POST /api/jobs                 upload a CSV / LAS / WITSML file -> validated + stored, job "Received"
/// 2. POST /api/jobs/{id}/start      user picks speed (1x, 2x, 5x, 10x) -> header to product store, data to data store
/// 3. POST /api/jobs/{id}/stop       stop the running job
/// </summary>
[ApiController]
[Authorize]   // every endpoint needs a valid JWT (see Jwt settings)
[Route("api/jobs")]
[ProducesResponseType(StatusCodes.Status401Unauthorized)]
[ProducesResponseType(StatusCodes.Status403Forbidden)]
[Produces("application/json")]
public sealed class JobsController(
    IJobService jobService,
    IFileValidator fileValidator,
    IOptions<SimulationOptions> simulationOptions,
    IOptions<JobStorageOptions> storageOptions) : ControllerBase
{
    // ---------------- Upload (receive the job) ----------------

    /// <summary>
    /// Uploads a log file (the file is the only field). It is checked for (1) Format: CSV, LAS or WITSML, (2) Structure: a proper file of that
    /// format, (3) LogType: time or depth log. A valid file is stored and a job is created in status Received.
    /// </summary>
    /// <response code="201">Valid; job created. The body has the job and the validation report.</response>
    /// <response code="400">Invalid file; the body is the validation report (see checks).</response>
    [HttpPost]
    [Consumes("multipart/form-data")]
    [ProducesResponseType<UploadJobResponse>(StatusCodes.Status201Created)]
    [ProducesResponseType<FileValidationReport>(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<UploadJobResponse>> Upload([FromForm] UploadFileRequest request, CancellationToken ct)
    {
        var (report, log) = await fileValidator.ValidateAsync(request.File, ct);
        if (!report.IsValid)
            return BadRequest(report);

        var registered = await jobService.RegisterAsync(request.File!, log!, ct);
        var reportWithNotes = registered.Warnings.Count == 0
            ? report
            : report with { Warnings = [.. report.Warnings, .. registered.Warnings] };

        return CreatedAtAction(nameof(GetById), new { id = registered.Job.Id },
            new UploadJobResponse(JobResponse.From(registered.Job), reportWithNotes));
    }

    /// <summary>Runs the same three checks as upload without storing the file or creating a job.</summary>
    [HttpPost("validate")]
    [Consumes("multipart/form-data")]
    [ProducesResponseType<FileValidationReport>(StatusCodes.Status200OK)]
    [ProducesResponseType<FileValidationReport>(StatusCodes.Status400BadRequest)]
    public async Task<ActionResult<FileValidationReport>> Validate([FromForm] UploadFileRequest request, CancellationToken ct)
    {
        var (report, _) = await fileValidator.ValidateAsync(request.File, ct);
        return report.IsValid ? Ok(report) : BadRequest(report);
    }

    /// <summary>Choices for the UI: allowed speeds, loop limit, file size limit and file types.</summary>
    [HttpGet("options")]
    public SimulationOptionsResponse GetOptions() => new(
        simulationOptions.Value.EffectiveSpeeds,
        simulationOptions.Value.MaxLoopCount,
        storageOptions.Value.MaxFileSizeMb,
        [".csv", ".las", ".xml", ".witsml"]);

    [HttpGet]
    public IEnumerable<JobResponse> GetAll() => jobService.GetAll().Select(JobResponse.From);

    [HttpGet("{id:guid}")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    public JobResponse GetById(Guid id) => JobResponse.From(jobService.Get(id));

    // ---------------- Start (user selects the speed) ----------------

    /// <summary>
    /// Starts the job at the chosen speed. The header is inserted into the product store, then the rows are
    /// sent to the data store: time logs keep the real gaps between rows divided by the speed; depth logs send
    /// one row per DepthRowIntervalMs divided by the speed. Also restarts a Stopped/Completed job or retries a Failed one.
    /// </summary>
    /// <response code="202">Started; poll GET /api/jobs/{id} for progress.</response>
    /// <response code="400">Speed missing or not allowed.</response>
    /// <response code="404">Job not found.</response>
    /// <response code="409">Job is already Running or Stopping.</response>
    [HttpPost("{id:guid}/start")]
    [Consumes("application/json")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status202Accepted)]
    [ProducesResponseType<ValidationProblemDetails>(StatusCodes.Status400BadRequest)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public ActionResult<JobResponse> Start(Guid id, [FromBody] StartJobRequest request)
    {
        var options = simulationOptions.Value;
        var errors = new Dictionary<string, string[]>();

        if (request.Speed is null)
            errors[nameof(request.Speed)] = [$"Choose a speed: {SpeedList(options)}."];
        else if (!options.EffectiveSpeeds.Contains(request.Speed.Value))
            errors[nameof(request.Speed)] = [$"Speed {request.Speed} is not allowed. Choose {SpeedList(options)}."];

        var loopCount = request.LoopCount ?? 1;
        if (loopCount < 1 || loopCount > options.MaxLoopCount)
            errors[nameof(request.LoopCount)] = [$"LoopCount must be between 1 and {options.MaxLoopCount}."];

        if (errors.Count > 0)
            return ValidationFailed(errors);

        var job = jobService.Start(id, request.Speed!.Value, loopCount);
        return AcceptedAtAction(nameof(GetById), new { id }, JobResponse.From(job));
    }

    // ---------------- Stop ----------------

    /// <summary>Stops the job.</summary>
    /// <response code="200">Job is Stopped (also returned if it was already stopped).</response>
    /// <response code="202">Cancellation requested but the job is still Stopping.</response>
    /// <response code="404">Job not found.</response>
    /// <response code="409">Job already Completed or Failed.</response>
    [HttpPost("{id:guid}/stop")]
    [ProducesResponseType<JobResponse>(StatusCodes.Status200OK)]
    [ProducesResponseType<JobResponse>(StatusCodes.Status202Accepted)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status404NotFound)]
    [ProducesResponseType<ProblemDetails>(StatusCodes.Status409Conflict)]
    public async Task<ActionResult<JobResponse>> Stop(Guid id, CancellationToken ct)
    {
        var result = await jobService.StopAsync(id, ct);
        var response = JobResponse.From(result.Job);

        return result.Completed && response.Status == JobStatus.Stopped
            ? Ok(response)
            : AcceptedAtAction(nameof(GetById), new { id }, response);
    }

    private static string SpeedList(SimulationOptions options) =>
        string.Join(", ", options.EffectiveSpeeds.Select(s => $"{s} ({s}x)"));

    private ActionResult ValidationFailed(Dictionary<string, string[]> errors) =>
        ValidationProblem(new ValidationProblemDetails(errors)
        {
            Title = "The request is invalid.",
            Status = StatusCodes.Status400BadRequest
        });
}
