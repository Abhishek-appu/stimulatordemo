namespace Simulator.Api.Configuration;

public enum StoreAuthMode
{
    /// <summary>No Authorization header is sent.</summary>
    None,

    /// <summary>
    /// OAuth2 client credentials: the Simulator gets its own token from TokenEndpoint with
    /// ClientId + ClientSecret, caches it and refreshes it before it expires.
    /// </summary>
    ClientCredentials,

    /// <summary>A fixed token from StaticToken. For short manual tests only; it will expire.</summary>
    StaticToken
}

/// <summary>
/// How the Simulator authenticates to the Product Store and Data Store ("StoreAuth" section).
/// One token is shared by both stores.
/// </summary>
public sealed class StoreAuthOptions
{
    public const string SectionName = "StoreAuth";

    public StoreAuthMode Mode { get; set; } = StoreAuthMode.ClientCredentials;

    /// <summary>
    /// OAuth2 token URL, e.g.
    /// Entra ID: https://login.microsoftonline.com/{tenant-id}/oauth2/v2.0/token
    /// Keycloak: https://{host}/realms/{realm}/protocol/openid-connect/token
    /// </summary>
    public string? TokenEndpoint { get; set; }

    /// <summary>The Simulator's own client/app id registered in the identity provider.</summary>
    public string? ClientId { get; set; }

    /// <summary>The Simulator's client secret. Keep it in user secrets / environment variable / Key Vault.</summary>
    public string? ClientSecret { get; set; }

    /// <summary>Scope to request, e.g. "api://{stores-app-id}/.default" for Entra ID. Optional for some providers.</summary>
    public string? Scope { get; set; }

    /// <summary>Optional "audience" form field (needed by Auth0 and some others).</summary>
    public string? Audience { get; set; }

    /// <summary>Mode StaticToken only.</summary>
    public string? StaticToken { get; set; }

    /// <summary>Get a new token this many seconds before the current one expires.</summary>
    public int RefreshBeforeExpirySeconds { get; set; } = 120;

    public int TimeoutSeconds { get; set; } = 30;
}
