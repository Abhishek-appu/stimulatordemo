namespace Simulator.Api.Configuration;

/// <summary>
/// JWT bearer validation settings ("Jwt" section). Use ONE of the two modes:
///
/// 1. Authority mode (Azure AD / Entra ID, Keycloak, Duende IdentityServer, Auth0 ...):
///    set Authority + Audience. Signing keys and issuer are read from
///    {Authority}/.well-known/openid-configuration and refreshed automatically.
///
/// 2. Signing-key mode (your own auth service signs tokens with a shared secret, HS256):
///    set Issuer + Audience + SigningKey (at least 32 characters).
/// </summary>
public sealed class JwtOptions
{
    public const string SectionName = "Jwt";

    /// <summary>When false, endpoints are open (no token needed). Keep true outside local testing.</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>Authority mode: the token issuer's base URL, e.g. https://login.microsoftonline.com/{tenantId}/v2.0</summary>
    public string? Authority { get; set; }

    /// <summary>Expected "aud" claim. Required in both modes.</summary>
    public string? Audience { get; set; }

    /// <summary>Expected "iss" claim. Required in signing-key mode; optional extra check in authority mode.</summary>
    public string? Issuer { get; set; }

    /// <summary>Signing-key mode: the shared HS256 secret. Keep it out of source control (user secrets / env var / Key Vault).</summary>
    public string? SigningKey { get; set; }

    /// <summary>Authority mode: require https for the metadata address. Only turn off for a local http identity server.</summary>
    public bool RequireHttpsMetadata { get; set; } = true;

    /// <summary>Allowed clock difference when checking exp / nbf.</summary>
    public int ClockSkewSeconds { get; set; } = 30;

    /// <summary>Optional. Token must contain this scope (in "scp" or "scope").</summary>
    public string? RequiredScope { get; set; }

    /// <summary>Optional. Token must contain this role (in "roles" or "role").</summary>
    public string? RequiredRole { get; set; }

    /// <summary>Development only, signing-key mode only: enables POST /dev/token to create test tokens.</summary>
    public bool EnableDevTokenEndpoint { get; set; }

    public bool UsesAuthority => !string.IsNullOrWhiteSpace(Authority);
    public bool UsesSigningKey => !string.IsNullOrWhiteSpace(SigningKey);
}
