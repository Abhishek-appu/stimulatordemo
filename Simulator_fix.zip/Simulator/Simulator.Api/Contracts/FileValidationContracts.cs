using System.Text.Json.Serialization;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;

namespace Simulator.Api.Contracts;

public static class CheckNames
{
    public const string Format = "Format";
    public const string Structure = "Structure";
    public const string LogType = "LogType";
}

[JsonConverter(typeof(JsonStringEnumConverter))]
public enum CheckStatus
{
    Passed,
    Failed,
    Skipped
}

/// <summary>Result of one of the three upload checks.</summary>
public sealed record ValidationCheck(string Name, CheckStatus Status, IReadOnlyList<string> Messages)
{
    public static ValidationCheck Pass(string name, string message) => new(name, CheckStatus.Passed, [message]);
    public static ValidationCheck Fail(string name, string message) => new(name, CheckStatus.Failed, [message]);
    public static ValidationCheck Fail(string name, IReadOnlyList<string> messages) => new(name, CheckStatus.Failed, messages.ToArray());
    public static ValidationCheck Skip(string name, string message) => new(name, CheckStatus.Skipped, [message]);
}

/// <summary>What was found in the file (only when it is valid).</summary>
public sealed record LogSummary(
    string IndexMnemonic,
    string IndexUnit,
    string? StartIndex,
    string? EndIndex,
    int RowCount,
    IReadOnlyList<ChannelDefinition> Channels,
    string? WellName,
    string? WellboreName,
    string? LogName);

/// <summary>Returned by upload and validate. On failure, check <see cref="Checks"/> to see what was wrong.</summary>
public sealed record FileValidationReport(
    string FileName,
    bool IsValid,
    FileFormat? Format,
    string? FormatVersion,
    LogType LogType,
    IReadOnlyList<ValidationCheck> Checks,
    IReadOnlyList<string> Warnings,
    LogSummary? Summary);
