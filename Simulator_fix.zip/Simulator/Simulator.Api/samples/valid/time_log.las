~Version Information
 VERS.                 2.0 :   CWLS LOG ASCII STANDARD - VERSION 2.0
 WRAP.                  NO :   ONE LINE PER DEPTH STEP
~Well Information
 STRT.S                0.0 :   START DEPTH
 STOP.S              58.0 :   STOP DEPTH
 STEP.S                2.0 :   STEP
 NULL.             -999.25 :   NULL VALUE
 COMP.        ACME OIL     :   COMPANY
 WELL.        WELL-A1      :   WELL
 UWI.         100123456789 :   UNIQUE WELL ID
~Curve Information
 TIME.S                    :   ELAPSED TIME
 HKLD.KLBF                 :   HOOKLOAD
 SPP .PSI                  :   STANDPIPE PRESSURE
~A  DEPTH     GR      RHOB
     0.0  200.00   3000.0
     2.0  201.00   3003.0
     4.0  202.00   3006.0
     6.0  203.00   3009.0
     8.0  204.00   3012.0
    10.0  205.00   3015.0
    12.0  206.00   3018.0
    14.0  207.00   3021.0
    16.0  208.00   3024.0
    18.0  209.00   3027.0
    20.0  210.00   3030.0
    22.0  211.00   3033.0
    24.0  212.00   3036.0
    26.0  213.00   3039.0
    28.0  214.00   3042.0
    30.0  215.00   3045.0
    32.0  216.00   3048.0
    34.0  217.00   3051.0
    36.0  218.00   3054.0
    38.0  219.00   3057.0
    40.0  220.00   3060.0
    42.0  221.00   3063.0
    44.0  222.00   3066.0
    46.0  223.00   3069.0
    48.0  224.00   3072.0
    50.0  225.00   3075.0
    52.0  226.00   3078.0
    54.0  227.00   3081.0
    56.0  228.00   3084.0
    58.0  229.00   3087.0
