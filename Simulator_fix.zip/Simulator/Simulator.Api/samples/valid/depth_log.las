~Version Information
 VERS.                 2.0 :   CWLS LOG ASCII STANDARD - VERSION 2.0
 WRAP.                  NO :   ONE LINE PER DEPTH STEP
~Well Information
 STRT.M             1500.0 :   START DEPTH
 STOP.M             1512.0 :   STOP DEPTH
 STEP.M                0.5 :   STEP
 NULL.             -999.25 :   NULL VALUE
 COMP.        ACME OIL     :   COMPANY
 WELL.        WELL-A1      :   WELL
 UWI.         100123456789 :   UNIQUE WELL ID
~Curve Information
 DEPT.M                    :   MEASURED DEPTH
 GR  .GAPI                 :   GAMMA RAY
 RHOB.G/C3                 :   BULK DENSITY
~A  DEPTH     GR      RHOB
  1500.0   60.00     2.45
  1500.5   61.00     2.45
  1501.0   62.00     2.45
  1501.5   63.00     2.45
  1502.0   64.00  -999.25
  1502.5   65.00     2.45
  1503.0   66.00     2.45
  1503.5   67.00     2.45
  1504.0   68.00     2.45
  1504.5   69.00     2.45
  1505.0   70.00     2.45
  1505.5   71.00     2.45
  1506.0   72.00     2.45
  1506.5   73.00     2.45
  1507.0   74.00     2.45
  1507.5   75.00     2.45
  1508.0   76.00     2.45
  1508.5   77.00     2.45
  1509.0   78.00     2.45
  1509.5   79.00     2.45
  1510.0   80.00     2.45
  1510.5   81.00     2.45
  1511.0   82.00     2.45
  1511.5   83.00     2.45
  1512.0   84.00     2.45
