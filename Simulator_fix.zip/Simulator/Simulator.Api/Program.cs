using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.OpenApi.Models;
using Simulator.Api.Configuration;
using Simulator.Api.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

// Allow uploads up to the configured size (plus room for the other form fields).
var maxFileSizeMb = builder.Configuration.GetValue<int?>($"{JobStorageOptions.SectionName}:{nameof(JobStorageOptions.MaxFileSizeMb)}") ?? 100;
var maxRequestBytes = (maxFileSizeMb + 1) * 1024L * 1024L;
builder.WebHost.ConfigureKestrel(k => k.Limits.MaxRequestBodySize = maxRequestBytes);
builder.Services.Configure<FormOptions>(f => f.MultipartBodyLengthLimit = maxRequestBytes);

builder.Services
    .AddControllers()
    .AddJsonOptions(o => o.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter()));

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(swagger =>
{
    // Adds the "Authorize" button: paste a token (without the word "Bearer").
    var bearer = new OpenApiSecurityScheme
    {
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Name = "Authorization",
        Description = "JWT access token",
        Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" }
    };
    swagger.AddSecurityDefinition("Bearer", bearer);
    swagger.AddSecurityRequirement(new OpenApiSecurityRequirement { [bearer] = [] });
});
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<JobExceptionHandler>();
builder.Services.AddHealthChecks();

builder.Services.AddJwtValidation(builder.Configuration);
builder.Services.AddSimulator(builder.Configuration);

var app = builder.Build();

app.UseExceptionHandler();
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthentication();   // reads and validates the Bearer token
app.UseAuthorization();    // enforces [Authorize]

app.MapControllers();
app.MapHealthChecks("/health").AllowAnonymous();
app.MapDevTokenEndpoint();

app.Run();
