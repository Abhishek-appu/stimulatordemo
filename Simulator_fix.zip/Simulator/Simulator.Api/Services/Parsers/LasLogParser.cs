using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// LAS 1.2 / 2.0 rules (LAS 3.0 is rejected):
/// <list type="bullet">
/// <item>Sections ~V, ~W, ~C and ~A are required; ~V must be first and ~A must be last.</item>
/// <item>~V must have VERS (1.2 or 2.0) and WRAP (YES or NO).</item>
/// <item>~W should have STRT, STOP, STEP and NULL (missing ones are warnings).</item>
/// <item>~C must list the index curve first and at least one data curve; no duplicates.</item>
/// <item>~A values must be numbers; with WRAP NO every line has one value per curve.</item>
/// </list>
/// Log type comes from the first curve: DEPT/DEPTH/MD/TVD (or unit m/ft) => depth, TIME/ETIM (or unit s/ms) => time.
/// </summary>
public sealed class LasLogParser : ILogFileParser
{
    private static readonly string[] DepthMnemonics = ["DEPT", "DEPTH", "MD", "TVD", "BDEP", "HDEP"];
    private static readonly string[] TimeMnemonics = ["TIME", "ETIM", "DATETIME", "INDEX_TIME", "TIM"];
    private static readonly string[] DepthUnits = ["m", "ft", "f", "meter", "meters", "feet"];
    private static readonly string[] TimeUnits = ["s", "sec", "ms", "msec", "min", "h", "hr"];

    public FileFormat Format => FileFormat.Las;

    public async Task<ParseOutcome> ParseAsync(Stream stream, CancellationToken ct = default)
    {
        var outcome = new ParseOutcome(FileFormat.Las);

        var sections = new List<char>();
        var version = new Dictionary<string, HeaderLine>(StringComparer.OrdinalIgnoreCase);
        var well = new Dictionary<string, HeaderLine>(StringComparer.OrdinalIgnoreCase);
        var curves = new List<ChannelDefinition>();
        var dataLines = new List<(int Number, string Text)>();
        var section = '\0';

        using (var reader = new StreamReader(stream, leaveOpen: true))
        {
            var lineNumber = 0;
            string? line;
            while ((line = await reader.ReadLineAsync(ct)) is not null)
            {
                lineNumber++;
                var trimmed = line.Trim();
                if (trimmed.Length == 0 || trimmed.StartsWith('#')) continue;

                if (trimmed.StartsWith('~'))
                {
                    if (section == 'A')
                        outcome.StructureError($"Line {lineNumber}: the ~A (data) section must be the last section.");
                    section = trimmed.Length > 1 ? char.ToUpperInvariant(trimmed[1]) : '?';
                    sections.Add(section);
                    continue;
                }

                if (section == '\0')
                {
                    outcome.StructureError($"Line {lineNumber}: text found before the first section. A LAS file must start with ~Version.");
                    section = '?';
                    continue;
                }

                switch (section)
                {
                    case 'V':
                    case 'W':
                    case 'C':
                        var header = HeaderLine.Parse(trimmed);
                        if (header is null)
                        {
                            outcome.StructureError($"Line {lineNumber}: expected 'MNEM.UNIT  VALUE : DESCRIPTION' but found '{Shorten(trimmed)}'.");
                            break;
                        }
                        if (section == 'V') version[header.Mnemonic] = header;
                        else if (section == 'W') well[header.Mnemonic] = header;
                        else curves.Add(new ChannelDefinition(header.Mnemonic, header.Unit, NullIfEmpty(header.Description)));
                        break;

                    case 'A':
                        dataLines.Add((lineNumber, trimmed));
                        break;
                }
            }
        }

        // ----- Sections -----
        if (sections.Count == 0)
        {
            outcome.StructureError("No LAS sections were found. A LAS file needs ~Version, ~Well, ~Curve and ~A sections.");
            return outcome;
        }
        if (sections[0] != 'V')
            outcome.StructureError("The first section must be ~Version (~V).");
        foreach (var (code, name) in new[] { ('V', "~Version"), ('W', "~Well"), ('C', "~Curve"), ('A', "~A (data)") })
            if (!sections.Contains(code))
                outcome.StructureError($"The required {name} section is missing.");

        // ----- ~Version -----
        var wrap = false;
        if (version.TryGetValue("VERS", out var vers))
        {
            outcome.FormatVersion = vers.Value;
            if (ValueParsing.TryParseNumber(vers.Value, out var v) && v >= 3)
                outcome.StructureError($"LAS version {vers.Value} is not supported. Only LAS 1.2 and 2.0 files are accepted.");
            else if (vers.Value is not ("1.2" or "1.20" or "2.0" or "2.00" or "2"))
                outcome.StructureError($"VERS must be 1.2 or 2.0 but is '{vers.Value}'.");
        }
        else if (sections.Contains('V'))
            outcome.StructureError("~Version section is missing the VERS line.");

        if (version.TryGetValue("WRAP", out var wrapLine))
        {
            if (wrapLine.Value.Equals("YES", StringComparison.OrdinalIgnoreCase)) wrap = true;
            else if (!wrapLine.Value.Equals("NO", StringComparison.OrdinalIgnoreCase))
                outcome.StructureError($"WRAP must be YES or NO but is '{wrapLine.Value}'.");
        }
        else if (sections.Contains('V'))
            outcome.StructureError("~Version section is missing the WRAP line.");

        // ----- ~Well -----
        foreach (var required in new[] { "STRT", "STOP", "STEP", "NULL" })
            if (sections.Contains('W') && !well.ContainsKey(required))
                outcome.Warning($"~Well section has no {required} line.");

        double? nullValue = well.TryGetValue("NULL", out var nullLine) && ValueParsing.TryParseNumber(nullLine.Value, out var nv) ? nv : null;

        // ----- ~Curve -----
        if (sections.Contains('C') && curves.Count < 2)
            outcome.StructureError($"~Curve section must list the index curve and at least one data curve (found {curves.Count}).");
        foreach (var dup in curves.GroupBy(c => c.Mnemonic, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
            outcome.StructureError($"Curve '{dup.Key}' is listed more than once in ~Curve.");

        if (sections.Contains('A') && dataLines.Count == 0)
            outcome.StructureError("The ~A section has no data.");

        if (outcome.HasErrors) return outcome;

        // ----- Log type from the index curve -----
        var index = curves[0];
        var logType = DetectLogType(index);
        outcome.LogType = logType;
        if (logType == LogType.Unknown)
        {
            outcome.LogTypeError($"Cannot tell whether index curve '{index.Mnemonic}' (unit '{index.Unit}') is time or depth. " +
                                 "Use DEPT/MD (m or ft) for depth or TIME/ETIM (s or ms) for time.");
            return outcome;
        }

        // ----- ~A data -----
        var rows = SplitRows(outcome, dataLines, curves.Count, wrap);
        var points = new List<DataPoint>(rows.Count);

        foreach (var (rowNumber, tokens) in rows)
        {
            if (outcome.TooManyErrors) break;

            if (!ValueParsing.TryParseNumber(tokens[0], out var indexValue))
            {
                outcome.StructureError($"{rowNumber}: index value '{tokens[0]}' is not a number.");
                continue;
            }
            if (IsNull(indexValue, nullValue))
            {
                outcome.LogTypeError($"{rowNumber}: the index value is the NULL value ({tokens[0]}).");
                continue;
            }

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            for (var c = 1; c < curves.Count; c++)
            {
                if (!ValueParsing.TryParseNumber(tokens[c], out var value))
                    outcome.StructureError($"{rowNumber}, curve '{curves[c].Mnemonic}': '{tokens[c]}' is not a number.");
                else if (!IsNull(value, nullValue))
                    values[curves[c].Mnemonic] = value;
            }

            if (logType == LogType.Time)
            {
                ValueParsing.TryParseTime(tokens[0], index.Unit, out var time);
                points.Add(new DataPoint(time, null, values));
            }
            else
            {
                points.Add(new DataPoint(null, indexValue, values));
            }
        }

        CompareWithHeader(outcome, well, logType, points);
        IndexChecks.Validate(outcome, logType, points);
        if (outcome.HasErrors) return outcome;

        var wellName = Value(well, "WELL");
        outcome.Log = new ParsedLog(FileFormat.Las, outcome.FormatVersion, logType, index.Mnemonic, index.Unit,
            new LogHeaderInfo(WellName: wellName, WellUid: Value(well, "UWI") ?? Value(well, "API")),
            curves.Skip(1).ToList(), points);
        return outcome;
    }

    private static List<(string RowLabel, string[] Tokens)> SplitRows(
        ParseOutcome outcome, List<(int Number, string Text)> lines, int curveCount, bool wrap)
    {
        var rows = new List<(string, string[])>();

        if (!wrap)
        {
            foreach (var (number, text) in lines)
            {
                var tokens = text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
                if (tokens.Length != curveCount)
                {
                    outcome.StructureError($"Line {number}: expected {curveCount} values (one per curve) but found {tokens.Length}.");
                    if (outcome.TooManyErrors) break;
                    continue;
                }
                rows.Add(($"Line {number}", tokens));
            }
            return rows;
        }

        // WRAP YES: values for one row may span several lines.
        var all = lines.SelectMany(l => l.Text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)).ToArray();
        if (all.Length % curveCount != 0)
            outcome.StructureError($"The ~A section has {all.Length} values, which is not a whole number of rows for {curveCount} curves.");
        for (var i = 0; i + curveCount <= all.Length; i += curveCount)
            rows.Add(($"Data row {i / curveCount + 1}", all[i..(i + curveCount)]));
        return rows;
    }

    private static void CompareWithHeader(ParseOutcome outcome, Dictionary<string, HeaderLine> well, LogType logType, List<DataPoint> points)
    {
        if (logType != LogType.Depth || points.Count == 0) return;

        void Check(string mnemonic, double? actual)
        {
            if (well.TryGetValue(mnemonic, out var line) && ValueParsing.TryParseNumber(line.Value, out var expected)
                && actual.HasValue && Math.Abs(expected - actual.Value) > 1e-6 * Math.Max(1, Math.Abs(expected)))
                outcome.Warning($"{mnemonic} in ~Well is {line.Value} but the data {(mnemonic == "STRT" ? "starts" : "ends")} at {actual}.");
        }

        Check("STRT", points[0].Depth);
        Check("STOP", points[^1].Depth);
    }

    private static LogType DetectLogType(ChannelDefinition index)
    {
        if (DepthMnemonics.Contains(index.Mnemonic, StringComparer.OrdinalIgnoreCase)) return LogType.Depth;
        if (TimeMnemonics.Contains(index.Mnemonic, StringComparer.OrdinalIgnoreCase)) return LogType.Time;
        if (DepthUnits.Contains(index.Unit, StringComparer.OrdinalIgnoreCase)) return LogType.Depth;
        if (TimeUnits.Contains(index.Unit, StringComparer.OrdinalIgnoreCase)) return LogType.Time;
        return LogType.Unknown;
    }

    private static bool IsNull(double value, double? nullValue) =>
        nullValue.HasValue && Math.Abs(value - nullValue.Value) < 1e-9;

    private static string? Value(Dictionary<string, HeaderLine> lines, string mnemonic)
    {
        if (!lines.TryGetValue(mnemonic, out var line)) return null;
        // LAS 1.2 often puts the value in the description ("WELL.  WELL : MY WELL NAME").
        var value = line.Value.Length > 0 ? line.Value : line.Description;
        return NullIfEmpty(value);
    }

    private static string? NullIfEmpty(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private static string Shorten(string s) => s.Length <= 60 ? s : s[..60] + "…";

    /// <summary>One "MNEM.UNIT  VALUE : DESCRIPTION" line.</summary>
    private sealed record HeaderLine(string Mnemonic, string Unit, string Value, string Description)
    {
        public static HeaderLine? Parse(string line)
        {
            var dot = line.IndexOf('.');
            if (dot <= 0) return null;

            var colon = line.LastIndexOf(':');
            if (colon < dot) colon = line.Length;

            var mnemonic = line[..dot].Trim();
            var rest = line[(dot + 1)..colon];
            var unitEnd = 0;
            while (unitEnd < rest.Length && !char.IsWhiteSpace(rest[unitEnd])) unitEnd++;

            var description = colon < line.Length ? line[(colon + 1)..].Trim() : "";
            return mnemonic.Length == 0 ? null : new HeaderLine(mnemonic, rest[..unitEnd], rest[unitEnd..].Trim(), description);
        }
    }
}
