using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

/// <summary>
/// CSV rules:
/// <list type="bullet">
/// <item>First non-empty line is the header. Delimiter is comma, semicolon or tab (detected from the header).</item>
/// <item>Units can be in the header ("ROP (m/h)" / "ROP [m/h]") or in an optional second row of units.</item>
/// <item>The index column is found by name: time-like (Time, DateTime, Timestamp…) or depth-like (Depth, DEPT, MD, TVD).
///       If the first column is an index column it wins; otherwise a time column is preferred over a depth column.</item>
/// <item>Every row must have the same number of columns; data values must be numbers (empty = no value).</item>
/// </list>
/// CSV files have no well/wellbore/log header, so those names come from the upload form or the file name.
/// </summary>
public sealed class CsvLogParser : ILogFileParser
{
    private static readonly string[] TimeNames = ["time", "datetime", "date_time", "timestamp", "index_time", "elapsed_time", "etim"];
    private static readonly string[] DepthNames = ["depth", "dept", "md", "tvd", "measured_depth", "bit_depth", "hole_depth"];

    public FileFormat Format => FileFormat.Csv;

    public async Task<ParseOutcome> ParseAsync(Stream stream, CancellationToken ct = default)
    {
        var outcome = new ParseOutcome(FileFormat.Csv);

        var lines = new List<(int Number, string Text)>();
        using (var reader = new StreamReader(stream, leaveOpen: true))
        {
            var number = 0;
            string? line;
            while ((line = await reader.ReadLineAsync(ct)) is not null)
            {
                number++;
                if (!string.IsNullOrWhiteSpace(line)) lines.Add((number, line));
            }
        }

        if (lines.Count == 0)
        {
            outcome.StructureError("The CSV file has no content.");
            return outcome;
        }

        // ----- Header -----
        var delimiter = DetectDelimiter(lines[0].Text);
        var headers = Split(lines[0].Text, delimiter).Select(ParseHeaderCell).ToArray();

        if (headers.Length < 2)
            outcome.StructureError($"Line {lines[0].Number}: the header must have an index column and at least one data column (found {headers.Length} column).");
        for (var i = 0; i < headers.Length; i++)
            if (headers[i].Mnemonic.Length == 0)
                outcome.StructureError($"Line {lines[0].Number}: column {i + 1} has no name.");
        foreach (var dup in headers.Where(h => h.Mnemonic.Length > 0).GroupBy(h => h.Mnemonic, StringComparer.OrdinalIgnoreCase).Where(g => g.Count() > 1))
            outcome.StructureError($"Line {lines[0].Number}: column '{dup.Key}' appears more than once.");
        if (outcome.HasErrors) return outcome;

        // ----- Log type (from the index column name) -----
        var (indexColumn, logType) = FindIndexColumn(headers);
        if (indexColumn < 0)
        {
            outcome.LogTypeError("No time or depth column was found. Name the index column e.g. 'Time' / 'DateTime' for a time log or 'Depth' / 'MD' for a depth log.");
            return outcome;
        }
        outcome.LogType = logType;
        var depthColumn = logType == LogType.Depth ? indexColumn : Array.FindIndex(headers, h => IsDepthName(h.Mnemonic));

        // ----- Optional units row -----
        var firstDataLine = 1;
        if (lines.Count > 1)
        {
            var cells = Split(lines[1].Text, delimiter);
            var looksLikeUnits = cells.Length == headers.Length
                && cells.All(c => !ValueParsing.TryParseNumber(c, out _))
                && !IsIndexValue(cells[indexColumn], logType, headers[indexColumn].Unit);
            if (looksLikeUnits)
            {
                for (var i = 0; i < headers.Length; i++)
                    if (headers[i].Unit.Length == 0) headers[i] = headers[i] with { Unit = cells[i] };
                firstDataLine = 2;
            }
        }

        // ----- Data rows -----
        var points = new List<DataPoint>();
        for (var r = firstDataLine; r < lines.Count && !outcome.TooManyErrors; r++)
        {
            var (lineNumber, text) = lines[r];
            var cells = Split(text, delimiter);
            if (cells.Length != headers.Length)
            {
                outcome.StructureError($"Line {lineNumber}: expected {headers.Length} values but found {cells.Length}.");
                continue;
            }

            var indexText = cells[indexColumn];
            DateTimeOffset? time = null;
            double? depth = null;

            if (logType == LogType.Time)
            {
                if (!ValueParsing.TryParseTime(indexText, headers[indexColumn].Unit, out var t))
                {
                    outcome.LogTypeError($"Line {lineNumber}: '{indexText}' in column '{headers[indexColumn].Mnemonic}' is not a valid date/time.");
                    continue;
                }
                time = t;
            }
            else if (!ValueParsing.TryParseNumber(indexText, out var d))
            {
                outcome.LogTypeError($"Line {lineNumber}: '{indexText}' in column '{headers[indexColumn].Mnemonic}' is not a valid depth.");
                continue;
            }
            else depth = d;

            var values = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            for (var c = 0; c < headers.Length; c++)
            {
                if (c == indexColumn || cells[c].Length == 0) continue;

                if (ValueParsing.TryParseNumber(cells[c], out var v))
                {
                    values[headers[c].Mnemonic] = v;
                    if (c == depthColumn) depth = v;
                }
                else
                {
                    outcome.StructureError($"Line {lineNumber}, column '{headers[c].Mnemonic}': '{cells[c]}' is not a number.");
                }
            }

            points.Add(new DataPoint(time, depth, values));
        }

        if (points.Count == 0 && !outcome.HasErrors)
            outcome.StructureError("The CSV file has a header but no data rows.");

        IndexChecks.Validate(outcome, logType, points);
        if (outcome.HasErrors) return outcome;

        var channels = headers.Where((_, i) => i != indexColumn).ToList();
        outcome.Log = new ParsedLog(FileFormat.Csv, null, logType, headers[indexColumn].Mnemonic, headers[indexColumn].Unit,
            new LogHeaderInfo(), channels, points);
        return outcome;
    }

    private static (int Column, LogType Type) FindIndexColumn(ChannelDefinition[] headers)
    {
        if (IsTimeName(headers[0].Mnemonic)) return (0, LogType.Time);
        if (IsDepthName(headers[0].Mnemonic)) return (0, LogType.Depth);

        var time = Array.FindIndex(headers, h => IsTimeName(h.Mnemonic));
        if (time >= 0) return (time, LogType.Time);

        var depth = Array.FindIndex(headers, h => IsDepthName(h.Mnemonic));
        return depth >= 0 ? (depth, LogType.Depth) : (-1, LogType.Unknown);
    }

    private static bool IsTimeName(string name)
    {
        var n = name.Trim().ToLowerInvariant().Replace(' ', '_');
        return TimeNames.Contains(n) || n.Contains("time");
    }

    private static bool IsDepthName(string name)
    {
        var n = name.Trim().ToLowerInvariant().Replace(' ', '_');
        return DepthNames.Contains(n) || n.Contains("depth");
    }

    private static bool IsIndexValue(string text, LogType type, string unit) =>
        type == LogType.Time ? ValueParsing.TryParseTime(text, unit, out _) : ValueParsing.TryParseNumber(text, out _);

    private static char DetectDelimiter(string header)
    {
        char[] candidates = [',', ';', '\t'];
        return candidates.OrderByDescending(c => header.Count(ch => ch == c)).First();
    }

    private static string[] Split(string line, char delimiter) =>
        line.Split(delimiter).Select(p => p.Trim().Trim('"').Trim()).ToArray();

    private static ChannelDefinition ParseHeaderCell(string header)
    {
        foreach (var (open, close) in new[] { ('(', ')'), ('[', ']') })
        {
            var start = header.IndexOf(open);
            var end = header.LastIndexOf(close);
            if (start > 0 && end > start)
                return new ChannelDefinition(header[..start].Trim(), header[(start + 1)..end].Trim());
        }
        return new ChannelDefinition(header.Trim(), "");
    }
}
