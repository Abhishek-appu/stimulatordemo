using System.Globalization;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

public interface ILogFileParser
{
    FileFormat Format { get; }

    /// <summary>
    /// Reads and validates the whole file. Problems are reported in the returned
    /// <see cref="ParseOutcome"/> instead of being thrown.
    /// </summary>
    Task<ParseOutcome> ParseAsync(Stream stream, CancellationToken ct = default);
}

public sealed record ChannelDefinition(string Mnemonic, string Unit, string? Description = null);

public sealed record DataPoint(DateTimeOffset? Time, double? Depth, IReadOnlyDictionary<string, double> Values);

/// <summary>Header information found in the file. Any of these may be missing (CSV has none).</summary>
public sealed record LogHeaderInfo(
    string? WellName = null,
    string? WellboreName = null,
    string? LogName = null,
    string? WellUid = null,
    string? WellboreUid = null,
    string? LogUid = null);

public sealed record ParsedLog(
    FileFormat Format,
    string? FormatVersion,
    LogType LogType,
    string IndexMnemonic,
    string IndexUnit,
    LogHeaderInfo Header,
    IReadOnlyList<ChannelDefinition> Channels,
    IReadOnlyList<DataPoint> Points)
{
    public string? StartIndex => Points.Count == 0 ? null : FormatIndex(Points[0]);
    public string? EndIndex => Points.Count == 0 ? null : FormatIndex(Points[^1]);

    private static string FormatIndex(DataPoint p) =>
        p.Time?.ToString("O", CultureInfo.InvariantCulture)
        ?? p.Depth?.ToString(CultureInfo.InvariantCulture)
        ?? "";
}

/// <summary>
/// Result of parsing a file. Errors are split by the check they belong to so the
/// upload response can show which check failed:
/// <list type="bullet">
/// <item>Structure: the file is not a proper CSV / LAS / WITSML file.</item>
/// <item>LogType: time/depth could not be determined, or the index values are invalid for it.</item>
/// </list>
/// </summary>
public sealed class ParseOutcome(FileFormat format)
{
    private const int MaxMessagesPerList = 25;

    public FileFormat Format { get; } = format;
    public string? FormatVersion { get; set; }
    public LogType LogType { get; set; } = LogType.Unknown;
    public List<string> StructureErrors { get; } = [];
    public List<string> LogTypeErrors { get; } = [];
    public List<string> Warnings { get; } = [];
    public ParsedLog? Log { get; set; }

    public bool HasErrors => StructureErrors.Count > 0 || LogTypeErrors.Count > 0;
    public bool IsValid => !HasErrors && Log is not null;

    /// <summary>True once enough errors were collected; parsers stop scanning rows then.</summary>
    public bool TooManyErrors => StructureErrors.Count + LogTypeErrors.Count >= MaxMessagesPerList;

    public void StructureError(string message) => Add(StructureErrors, message);
    public void LogTypeError(string message) => Add(LogTypeErrors, message);
    public void Warning(string message) => Add(Warnings, message);

    private static void Add(List<string> list, string message)
    {
        if (list.Count < MaxMessagesPerList) list.Add(message);
        else if (list.Count == MaxMessagesPerList) list.Add($"More problems were found; only the first {MaxMessagesPerList} are shown.");
    }
}
