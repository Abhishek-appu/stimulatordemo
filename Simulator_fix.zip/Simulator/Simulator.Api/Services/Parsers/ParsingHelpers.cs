using System.Globalization;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

internal static class ValueParsing
{
    public static bool TryParseNumber(string? text, out double value) =>
        double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) && double.IsFinite(value);

    /// <summary>
    /// A time index is either a date/time (ISO 8601 recommended) or a number meaning elapsed time
    /// in <paramref name="unit"/> (s by default; ms, min and h are also understood).
    /// Elapsed values are placed on a timeline starting at 1970-01-01 so that gaps between rows are kept.
    /// </summary>
    public static bool TryParseTime(string? text, string unit, out DateTimeOffset time)
    {
        time = default;
        if (string.IsNullOrWhiteSpace(text)) return false;

        if (TryParseNumber(text, out var elapsed))
        {
            try
            {
                time = unit.Trim().ToLowerInvariant() switch
                {
                    "ms" or "msec" => DateTimeOffset.UnixEpoch.AddMilliseconds(elapsed),
                    "min" or "mins" => DateTimeOffset.UnixEpoch.AddMinutes(elapsed),
                    "h" or "hr" or "hrs" => DateTimeOffset.UnixEpoch.AddHours(elapsed),
                    _ => DateTimeOffset.UnixEpoch.AddSeconds(elapsed)
                };
                return true;
            }
            catch (ArgumentOutOfRangeException)
            {
                return false;
            }
        }

        return DateTimeOffset.TryParse(text, CultureInfo.InvariantCulture,
            DateTimeStyles.AssumeUniversal | DateTimeStyles.AllowWhiteSpaces, out time);
    }
}

internal static class IndexChecks
{
    /// <summary>
    /// Time must go forward. Depth must keep going the same way (all increasing or all decreasing).
    /// Repeated index values only produce a warning.
    /// </summary>
    public static void Validate(ParseOutcome outcome, LogType logType, IReadOnlyList<DataPoint> points)
    {
        var duplicates = 0;

        if (logType == LogType.Time)
        {
            for (var i = 1; i < points.Count && !outcome.TooManyErrors; i++)
            {
                var previous = points[i - 1].Time;
                var current = points[i].Time;
                if (previous is null || current is null) continue;

                if (current < previous)
                    outcome.LogTypeError($"Data row {i + 1}: time {current:O} is earlier than the previous row ({previous:O}). Time must increase.");
                else if (current == previous)
                    duplicates++;
            }
        }
        else if (logType == LogType.Depth)
        {
            var direction = 0;
            for (var i = 1; i < points.Count; i++)
            {
                var previous = points[i - 1].Depth;
                var current = points[i].Depth;
                if (previous is null || current is null) continue;

                var sign = Math.Sign(current.Value - previous.Value);
                if (sign == 0) { duplicates++; continue; }
                if (direction == 0) { direction = sign; continue; }
                if (sign != direction)
                {
                    outcome.LogTypeError(
                        $"Data row {i + 1}: depth changes direction ({previous} -> {current}). Depth must keep increasing or keep decreasing.");
                    break;
                }
            }
        }

        if (duplicates > 0)
            outcome.Warning($"{duplicates} row(s) repeat the previous index value.");
    }
}
