using Simulator.Api.Models;

namespace Simulator.Api.Services.Parsers;

public interface ILogFileParserResolver
{
    ILogFileParser Get(FileFormat format);
}

public sealed class LogFileParserResolver(IEnumerable<ILogFileParser> parsers) : ILogFileParserResolver
{
    private readonly Dictionary<FileFormat, ILogFileParser> _byFormat = parsers.ToDictionary(p => p.Format);

    public ILogFileParser Get(FileFormat format) =>
        _byFormat.TryGetValue(format, out var parser)
            ? parser
            : throw new InvalidOperationException($"No parser is registered for {format}.");
}
