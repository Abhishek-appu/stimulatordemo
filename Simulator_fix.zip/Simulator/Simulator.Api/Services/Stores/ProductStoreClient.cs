using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Simulator.Api.Services.Stores;

/// <summary>HTTP client for the product store. BaseAddress, timeout and API key are set at registration.</summary>
public sealed class ProductStoreClient(HttpClient http) : IProductStoreClient
{
    internal static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        Converters = { new JsonStringEnumConverter() },
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    public Task<string> CreateWellAsync(WellHeader well, CancellationToken ct) =>
        PostForIdAsync("api/wells", well, ct);

    public Task<string> CreateWellboreAsync(string wellId, WellboreHeader wellbore, CancellationToken ct) =>
        PostForIdAsync($"api/wells/{Uri.EscapeDataString(wellId)}/wellbores", wellbore, ct);

    public Task<string> CreateChannelSetAsync(string wellboreId, LogHeader log, CancellationToken ct) =>
        PostForIdAsync($"api/wellbores/{Uri.EscapeDataString(wellboreId)}/channelSets", log, ct);

    public Task<string> CreateChannelAsync(string channelSetId, ChannelHeader channel, CancellationToken ct) =>
        PostForIdAsync($"api/channelSets/{Uri.EscapeDataString(channelSetId)}/channels", channel, ct);

    private async Task<string> PostForIdAsync<T>(string path, T body, CancellationToken ct)
    {
        using var response = await http.PostAsJsonAsync(path, body, Json, ct);
        response.EnsureSuccessStatusCode();

        var result = await response.Content.ReadFromJsonAsync<IdResponse>(Json, ct);
        return string.IsNullOrWhiteSpace(result?.Id)
            ? throw new InvalidOperationException($"Product store returned no id for '{path}'.")
            : result.Id;
    }

    private sealed record IdResponse(string Id);
}
