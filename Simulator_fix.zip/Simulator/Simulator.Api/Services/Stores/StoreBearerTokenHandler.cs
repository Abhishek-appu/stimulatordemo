using System.Net;
using System.Net.Http.Headers;

namespace Simulator.Api.Services.Stores;

/// <summary>
/// Added to the Product Store and Data Store HTTP clients. Puts "Authorization: Bearer {token}" on
/// every request. If a store answers 401 (e.g. the token was revoked), it gets a fresh token and
/// retries the request once.
/// </summary>
public sealed class StoreBearerTokenHandler(IStoreTokenProvider tokens) : DelegatingHandler
{
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        var token = await tokens.GetTokenAsync(ct);
        if (token is null) return await base.SendAsync(request, ct);

        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        var response = await base.SendAsync(request, ct);
        if (response.StatusCode != HttpStatusCode.Unauthorized) return response;

        tokens.Invalidate(token);
        var newToken = await tokens.GetTokenAsync(ct);
        if (newToken is null || newToken == token) return response;

        response.Dispose();
        using var retry = Clone(request);
        retry.Headers.Authorization = new AuthenticationHeaderValue("Bearer", newToken);
        return await base.SendAsync(retry, ct);
    }

    private static HttpRequestMessage Clone(HttpRequestMessage original)
    {
        // The JSON content used by the store clients can be sent again.
        var clone = new HttpRequestMessage(original.Method, original.RequestUri)
        {
            Content = original.Content,
            Version = original.Version,
            VersionPolicy = original.VersionPolicy,
        };
        foreach (var header in original.Headers)
            clone.Headers.TryAddWithoutValidation(header.Key, header.Value);
        return clone;
    }
}
