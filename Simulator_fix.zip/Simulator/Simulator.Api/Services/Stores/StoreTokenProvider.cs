using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;

namespace Simulator.Api.Services.Stores;

/// <summary>Gives out the Bearer token used for both the Product Store and the Data Store.</summary>
public interface IStoreTokenProvider
{
    /// <summary>Returns a valid token (cached, or a new one). Null when StoreAuth:Mode is None.</summary>
    Task<string?> GetTokenAsync(CancellationToken ct);

    /// <summary>Forget the cached token, e.g. after a store answered 401.</summary>
    void Invalidate(string rejectedToken);
}

/// <summary>Thrown when the identity provider refuses to give a token.</summary>
public sealed class StoreAuthenticationException(string message) : Exception(message);

/// <summary>
/// OAuth2 client-credentials token provider. One token is cached for the whole app and shared
/// by both store clients; only one refresh happens at a time even with many jobs running.
/// </summary>
public sealed class StoreTokenProvider(
    IHttpClientFactory httpClientFactory,
    IOptions<StoreAuthOptions> options,
    TimeProvider time,
    ILogger<StoreTokenProvider> logger) : IStoreTokenProvider
{
    public const string TokenClientName = "StoreAuth";

    private readonly StoreAuthOptions _options = options.Value;
    private readonly SemaphoreSlim _refreshLock = new(1, 1);
    private volatile CachedToken? _cached;

    public async Task<string?> GetTokenAsync(CancellationToken ct)
    {
        switch (_options.Mode)
        {
            case StoreAuthMode.None:
                return null;
            case StoreAuthMode.StaticToken:
                return _options.StaticToken;
        }

        var cached = _cached;
        if (cached is not null && !NeedsRefresh(cached)) return cached.AccessToken;

        await _refreshLock.WaitAsync(ct);
        try
        {
            // Another caller may have refreshed while we waited.
            cached = _cached;
            if (cached is not null && !NeedsRefresh(cached)) return cached.AccessToken;

            _cached = await RequestTokenAsync(ct);
            return _cached.AccessToken;
        }
        finally
        {
            _refreshLock.Release();
        }
    }

    public void Invalidate(string rejectedToken)
    {
        // Only drop it if nobody has refreshed it already.
        if (_cached?.AccessToken == rejectedToken)
        {
            _cached = null;
            logger.LogInformation("Store token was rejected; a new one will be requested");
        }
    }

    private bool NeedsRefresh(CachedToken token) =>
        time.GetUtcNow() >= token.ExpiresAt - TimeSpan.FromSeconds(_options.RefreshBeforeExpirySeconds);

    private async Task<CachedToken> RequestTokenAsync(CancellationToken ct)
    {
        var form = new Dictionary<string, string>
        {
            ["grant_type"] = "client_credentials",
            ["client_id"] = _options.ClientId!,
            ["client_secret"] = _options.ClientSecret!,
        };
        if (!string.IsNullOrWhiteSpace(_options.Scope)) form["scope"] = _options.Scope;
        if (!string.IsNullOrWhiteSpace(_options.Audience)) form["audience"] = _options.Audience;

        var http = httpClientFactory.CreateClient(TokenClientName);
        using var request = new HttpRequestMessage(HttpMethod.Post, _options.TokenEndpoint)
        {
            Content = new FormUrlEncodedContent(form)
        };
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

        HttpResponseMessage response;
        try
        {
            response = await http.SendAsync(request, ct);
        }
        catch (HttpRequestException ex)
        {
            throw new StoreAuthenticationException($"Could not reach the token endpoint {_options.TokenEndpoint}: {ex.Message}");
        }

        using (response)
        {
            var body = await response.Content.ReadAsStringAsync(ct);
            if (!response.IsSuccessStatusCode)
            {
                // OAuth2 errors look like { "error": "invalid_client", "error_description": "..." }. Never log the secret.
                throw new StoreAuthenticationException(
                    $"Token endpoint returned {(int)response.StatusCode}: {DescribeError(body)}");
            }

            var token = ParseToken(body);
            logger.LogInformation("Got a store access token, valid until {ExpiresAt:u}", token.ExpiresAt);
            return token;
        }
    }

    private CachedToken ParseToken(string body)
    {
        JsonElement root;
        try
        {
            root = JsonDocument.Parse(body).RootElement;
        }
        catch (JsonException)
        {
            throw new StoreAuthenticationException("Token endpoint did not return JSON.");
        }

        if (!root.TryGetProperty("access_token", out var accessTokenElement) || accessTokenElement.GetString() is not { Length: > 0 } accessToken)
            throw new StoreAuthenticationException("Token endpoint response has no access_token.");

        // expires_in may be a number or a string; fall back to the token's own "exp" claim, then 5 minutes.
        var now = time.GetUtcNow();
        DateTimeOffset expiresAt;
        if (root.TryGetProperty("expires_in", out var expiresIn) &&
            (expiresIn.ValueKind == JsonValueKind.Number ? expiresIn.TryGetInt32(out var seconds)
                                                         : int.TryParse(expiresIn.GetString(), out seconds)))
            expiresAt = now.AddSeconds(seconds);
        else
            expiresAt = ReadExpClaim(accessToken) ?? now.AddMinutes(5);

        return new CachedToken(accessToken, expiresAt);
    }

    private static DateTimeOffset? ReadExpClaim(string jwt)
    {
        var parts = jwt.Split('.');
        if (parts.Length < 2) return null;
        try
        {
            var payload = parts[1].Replace('-', '+').Replace('_', '/');
            payload = payload.PadRight(payload.Length + (4 - payload.Length % 4) % 4, '=');
            using var doc = JsonDocument.Parse(Encoding.UTF8.GetString(Convert.FromBase64String(payload)));
            return doc.RootElement.TryGetProperty("exp", out var exp) && exp.TryGetInt64(out var unix)
                ? DateTimeOffset.FromUnixTimeSeconds(unix)
                : null;
        }
        catch (Exception ex) when (ex is FormatException or JsonException)
        {
            return null;
        }
    }

    private static string DescribeError(string body)
    {
        try
        {
            var root = JsonDocument.Parse(body).RootElement;
            var error = root.TryGetProperty("error", out var e) ? e.GetString() : null;
            var description = root.TryGetProperty("error_description", out var d) ? d.GetString() : null;
            if (error is not null) return description is null ? error : $"{error} - {description}";
        }
        catch (JsonException)
        {
        }
        return body.Length > 300 ? body[..300] + "…" : body;
    }

    private sealed record CachedToken(string AccessToken, DateTimeOffset ExpiresAt);
}
