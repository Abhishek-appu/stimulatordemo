using System.Collections.Concurrent;
using Simulator.Api.Models;

namespace Simulator.Api.Services.Jobs;

public interface IJobRunner
{
    /// <summary>Starts executing a job that is already in <see cref="JobStatus.Running"/>.</summary>
    void Run(SimulationJob job);

    /// <summary>Requests cancellation of a running execution. Returns false if nothing is running.</summary>
    bool Cancel(Guid jobId);

    /// <summary>Waits until the execution ends. Returns false if it is still running after the timeout.</summary>
    Task<bool> WaitForExitAsync(Guid jobId, TimeSpan timeout, CancellationToken ct);

    bool IsRunning(Guid jobId);
}

/// <summary>
/// Owns the background executions. Each run gets its own DI scope (fresh HTTP clients) and its
/// own cancellation token, which is also cancelled when the application shuts down.
/// The final status (Completed / Stopped / Failed) is decided here.
/// </summary>
public sealed class JobRunner(
    IServiceScopeFactory scopeFactory,
    IJobStateMachine stateMachine,
    ILogger<JobRunner> logger) : IJobRunner, IHostedService
{
    private readonly ConcurrentDictionary<Guid, RunHandle> _runs = new();
    private readonly CancellationTokenSource _shutdown = new();

    public void Run(SimulationJob job)
    {
        var handle = new RunHandle(CancellationTokenSource.CreateLinkedTokenSource(_shutdown.Token));
        _runs[job.Id] = handle;
        handle.Task = Task.Run(() => ExecuteAsync(job, handle));
    }

    public bool Cancel(Guid jobId)
    {
        if (!_runs.TryGetValue(jobId, out var handle)) return false;
        try
        {
            handle.Cts.Cancel();
            return true;
        }
        catch (ObjectDisposedException)
        {
            return false; // finished in the meantime
        }
    }

    public async Task<bool> WaitForExitAsync(Guid jobId, TimeSpan timeout, CancellationToken ct)
    {
        if (!_runs.TryGetValue(jobId, out var handle) || handle.Task is null) return true;
        try
        {
            await handle.Task.WaitAsync(timeout, ct);
            return true;
        }
        catch (TimeoutException)
        {
            return false;
        }
    }

    public bool IsRunning(Guid jobId) => _runs.ContainsKey(jobId);

    private async Task ExecuteAsync(SimulationJob job, RunHandle handle)
    {
        var ct = handle.Cts.Token;
        try
        {
            await using var scope = scopeFactory.CreateAsyncScope();
            var executor = scope.ServiceProvider.GetRequiredService<IJobExecutor>();

            await executor.ExecuteAsync(job, ct);
            MarkFinished(job);
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            MarkStopped(job, _shutdown.IsCancellationRequested ? "Application shutting down" : "Cancelled");
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Job {JobId} failed", job.Id);
            lock (job.SyncRoot)
            {
                stateMachine.TryTransition(job, JobStatus.Failed, ex.Message);
            }
        }
        finally
        {
            _runs.TryRemove(new KeyValuePair<Guid, RunHandle>(job.Id, handle));
            handle.Cts.Dispose();
        }
    }

    /// <summary>
    /// All rows were sent. If a stop was requested at the same moment, honor the stop
    /// so the user sees the outcome they asked for.
    /// </summary>
    private void MarkFinished(SimulationJob job)
    {
        lock (job.SyncRoot)
        {
            if (job.Status == JobStatus.Stopping)
                stateMachine.TryTransition(job, JobStatus.Stopped, "Stop requested as the job finished");
            else
                stateMachine.TryTransition(job, JobStatus.Completed, "All rows sent");
        }
    }

    private void MarkStopped(SimulationJob job, string reason)
    {
        lock (job.SyncRoot)
        {
            if (job.Status == JobStatus.Running)
                stateMachine.TryTransition(job, JobStatus.Stopping, reason);
            stateMachine.TryTransition(job, JobStatus.Stopped, reason);
        }
    }

    public Task StartAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    /// <summary>Graceful shutdown: cancel every running job and wait for them to end.</summary>
    public async Task StopAsync(CancellationToken cancellationToken)
    {
        if (_runs.IsEmpty) return;

        logger.LogInformation("Stopping {Count} running job(s) for shutdown", _runs.Count);
        await _shutdown.CancelAsync();

        var tasks = _runs.Values.Select(h => h.Task).OfType<Task>().ToArray();
        try
        {
            await Task.WhenAll(tasks).WaitAsync(cancellationToken);
        }
        catch (OperationCanceledException)
        {
            logger.LogWarning("Shutdown timeout reached before all jobs stopped");
        }
    }

    private sealed class RunHandle(CancellationTokenSource cts)
    {
        public CancellationTokenSource Cts { get; } = cts;
        public Task? Task { get; set; }
    }
}
