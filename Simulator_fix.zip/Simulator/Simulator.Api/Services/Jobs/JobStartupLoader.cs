using System.Text.Json;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Services.Storage;

namespace Simulator.Api.Services.Jobs;

/// <summary>
/// Runs once when the app starts, before requests are accepted:
/// 1. Loads every "{jobId}.job.json" so GET /api/jobs shows jobs from before the restart.
///    A job that was Running/Stopping when the app stopped is marked Stopped (it can be started again).
/// 2. Recovers uploaded files that have no .job.json (e.g. uploaded by an older version):
///    the file is validated again and, if valid, listed as a Received job.
/// </summary>
public sealed class JobStartupLoader(
    IJobRepository repository,
    IJobFileStorage storage,
    IJobStateMachine stateMachine,
    ILogFileParserResolver parsers,
    TimeProvider time,
    ILogger<JobStartupLoader> logger) : IHostedService
{
    public async Task StartAsync(CancellationToken ct)
    {
        var root = storage.RootPath;
        if (!Directory.Exists(root)) return;

        var loaded = LoadRecords(root);
        var recovered = await RecoverOrphanFilesAsync(root, loaded, ct);

        logger.LogInformation("Loaded {Loaded} saved job(s) and recovered {Recovered} job(s) from files without a record in {Root}",
            loaded.Count, recovered, root);
    }

    public Task StopAsync(CancellationToken ct) => Task.CompletedTask;

    private HashSet<Guid> LoadRecords(string root)
    {
        var loaded = new HashSet<Guid>();

        foreach (var path in Directory.EnumerateFiles(root, "*" + FileJobRepository.RecordSuffix))
        {
            try
            {
                var record = JsonSerializer.Deserialize<JobRecord>(File.ReadAllText(path), FileJobRepository.Json)
                             ?? throw new JsonException("empty record");
                var job = record.ToJob(root);

                if (!File.Exists(job.StoredFilePath))
                {
                    logger.LogWarning("Skipping job {JobId}: its file {File} is missing", job.Id, job.StoredFilePath);
                    continue;
                }

                repository.Load(job);
                loaded.Add(job.Id);

                // It cannot still be running after a restart.
                if (job.Status is JobStatus.Running or JobStatus.Stopping)
                {
                    lock (job.SyncRoot)
                    {
                        stateMachine.TryTransition(job, JobStatus.Stopping, "Service restarted while the job was running");
                        stateMachine.TryTransition(job, JobStatus.Stopped, "Service restarted while the job was running");
                    }
                }
            }
            catch (Exception ex) when (ex is JsonException or IOException or NotSupportedException)
            {
                logger.LogWarning(ex, "Could not read job record {Path}; it was skipped", path);
            }
        }

        return loaded;
    }

    private async Task<int> RecoverOrphanFilesAsync(string root, HashSet<Guid> loaded, CancellationToken ct)
    {
        var recovered = 0;

        foreach (var path in Directory.EnumerateFiles(root))
        {
            var name = Path.GetFileName(path);
            if (name.EndsWith(FileJobRepository.RecordSuffix, StringComparison.OrdinalIgnoreCase) || name.EndsWith(".tmp")) continue;

            var extension = Path.GetExtension(name);
            var format = FileFormatDetector.FromExtension(extension);
            if (format is null || !Guid.TryParseExact(Path.GetFileNameWithoutExtension(name), "N", out var jobId) || loaded.Contains(jobId))
                continue;

            ParseOutcome outcome;
            try
            {
                await using var stream = storage.OpenRead(path);
                outcome = await parsers.Get(format.Value).ParseAsync(stream, ct);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                logger.LogWarning(ex, "Could not read {File}; it was skipped", path);
                continue;
            }

            if (outcome.Log is not { } log)
            {
                logger.LogWarning("Stored file {File} is not valid any more and was skipped", path);
                continue;
            }

            var baseName = Path.GetFileNameWithoutExtension(name);
            var receivedAt = new DateTimeOffset(File.GetCreationTimeUtc(path), TimeSpan.Zero);
            var job = new SimulationJob
            {
                Id = jobId,
                FileName = name,   // the original upload name was not saved by the older version
                StoredFilePath = path,
                Format = log.Format,
                FormatVersion = log.FormatVersion,
                LogType = log.LogType,
                IndexMnemonic = log.IndexMnemonic,
                IndexUnit = log.IndexUnit,
                StartIndex = log.StartIndex,
                EndIndex = log.EndIndex,
                WellName = log.Header.WellName ?? baseName,
                WellboreName = log.Header.WellboreName ?? log.Header.WellName ?? baseName,
                LogName = log.Header.LogName ?? baseName,
                WellUid = log.Header.WellUid,
                WellboreUid = log.Header.WellboreUid,
                LogUid = log.Header.LogUid,
                TotalRows = log.Points.Count,
                ChannelCount = log.Channels.Count,
                ReceivedAt = receivedAt,
            };
            job.AddHistory(new JobStatusChange(null, JobStatus.Received, time.GetUtcNow(), "Recovered from a stored file after restart"));

            repository.Add(job);   // also writes its .job.json so this happens only once
            recovered++;
        }

        return recovered;
    }
}
