using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Serialization;
using Simulator.Api.Models;
using Simulator.Api.Services.Storage;

namespace Simulator.Api.Services.Jobs;

public interface IJobRepository
{
    void Add(SimulationJob job);
    SimulationJob? Get(Guid id);
    IReadOnlyCollection<SimulationJob> GetAll();

    /// <summary>Writes the job's current state to disk (called on every status change).</summary>
    void Save(SimulationJob job);

    /// <summary>Puts a job loaded at startup into the list without re-saving it.</summary>
    void Load(SimulationJob job);
}

/// <summary>
/// Keeps jobs in memory for fast reads and saves each one as "{jobId}.job.json" next to its
/// uploaded file, so jobs survive a restart. <see cref="JobStartupLoader"/> reads them back.
/// </summary>
public sealed class FileJobRepository(IJobFileStorage storage, ILogger<FileJobRepository> logger) : IJobRepository
{
    public const string RecordSuffix = ".job.json";

    internal static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly ConcurrentDictionary<Guid, SimulationJob> _jobs = new();

    public void Add(SimulationJob job)
    {
        if (!_jobs.TryAdd(job.Id, job))
            throw new InvalidOperationException($"A job with id '{job.Id}' is already registered.");
        Save(job);
    }

    public void Load(SimulationJob job) => _jobs[job.Id] = job;

    public SimulationJob? Get(Guid id) => _jobs.GetValueOrDefault(id);

    public IReadOnlyCollection<SimulationJob> GetAll() =>
        _jobs.Values.OrderByDescending(j => j.ReceivedAt).ToList();

    public void Save(SimulationJob job)
    {
        JobRecord record;
        lock (job.SyncRoot)
        {
            record = JobRecord.From(job);
        }

        var path = RecordPath(storage.RootPath, job.Id);
        var temp = path + ".tmp";
        try
        {
            // Write to a temp file first so a crash never leaves a half-written record.
            File.WriteAllText(temp, JsonSerializer.Serialize(record, Json));
            File.Move(temp, path, overwrite: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            logger.LogError(ex, "Could not save job {JobId} to {Path}", job.Id, path);
        }
    }

    public static string RecordPath(string root, Guid jobId) => Path.Combine(root, $"{jobId:N}{RecordSuffix}");
}

/// <summary>What is written to "{jobId}.job.json".</summary>
public sealed record JobRecord(
    Guid Id,
    string FileName,
    string StoredFileName,
    FileFormat Format,
    string? FormatVersion,
    LogType LogType,
    string IndexMnemonic,
    string IndexUnit,
    string? StartIndex,
    string? EndIndex,
    string WellName,
    string WellboreName,
    string LogName,
    string? WellUid,
    string? WellboreUid,
    string? LogUid,
    int TotalRows,
    int ChannelCount,
    DateTimeOffset ReceivedAt,
    JobStatus Status,
    int? Speed,
    int LoopCount,
    int RowsSent,
    int CurrentLoop,
    int RunCount,
    DateTimeOffset? StartedAt,
    DateTimeOffset? EndedAt,
    string? ErrorMessage,
    string? WellId,
    string? WellboreId,
    string? ChannelSetId,
    IReadOnlyList<JobStatusChange> History)
{
    public static JobRecord From(SimulationJob j) => new(
        j.Id, j.FileName, Path.GetFileName(j.StoredFilePath), j.Format, j.FormatVersion, j.LogType,
        j.IndexMnemonic, j.IndexUnit, j.StartIndex, j.EndIndex, j.WellName, j.WellboreName, j.LogName,
        j.WellUid, j.WellboreUid, j.LogUid, j.TotalRows, j.ChannelCount, j.ReceivedAt,
        j.Status, j.Speed, j.LoopCount, j.RowsSent, j.CurrentLoop, j.RunCount, j.StartedAt, j.EndedAt,
        j.ErrorMessage, j.WellId, j.WellboreId, j.ChannelSetId, j.History);

    /// <param name="root">Storage folder; the stored file is looked up there so the folder can be moved.</param>
    public SimulationJob ToJob(string root)
    {
        var job = new SimulationJob
        {
            Id = Id,
            FileName = FileName,
            StoredFilePath = Path.Combine(root, StoredFileName),
            Format = Format,
            FormatVersion = FormatVersion,
            LogType = LogType,
            IndexMnemonic = IndexMnemonic,
            IndexUnit = IndexUnit,
            StartIndex = StartIndex,
            EndIndex = EndIndex,
            WellName = WellName,
            WellboreName = WellboreName,
            LogName = LogName,
            WellUid = WellUid,
            WellboreUid = WellboreUid,
            LogUid = LogUid,
            TotalRows = TotalRows,
            ChannelCount = ChannelCount,
            ReceivedAt = ReceivedAt,
            Speed = Speed,
            LoopCount = LoopCount,
            RunCount = RunCount,
            StartedAt = StartedAt,
            EndedAt = EndedAt,
            ErrorMessage = ErrorMessage,
            WellId = WellId,
            WellboreId = WellboreId,
            ChannelSetId = ChannelSetId,
        };
        job.Restore(Status, RowsSent, CurrentLoop, History ?? []);
        return job;
    }
}
