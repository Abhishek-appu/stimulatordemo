using Microsoft.Extensions.Options;
using Simulator.Api.Configuration;
using Simulator.Api.Models;
using Simulator.Api.Services.Parsers;
using Simulator.Api.Services.Storage;
using Simulator.Api.Services.Stores;

namespace Simulator.Api.Services.Jobs;

public interface IJobExecutor
{
    /// <summary>
    /// Runs one execution of the job:
    /// 1. parses the stored file,
    /// 2. inserts the header (well, wellbore, log/channel set, channels) into the product store,
    /// 3. sends every data row to the data store, paced by the chosen speed, for each loop.
    /// Honors <paramref name="ct"/> for stop.
    /// </summary>
    Task ExecuteAsync(SimulationJob job, CancellationToken ct);
}

public sealed class JobExecutor(
    IJobRepository repository,
    ILogFileParserResolver parsers,
    IJobFileStorage storage,
    IProductStoreClient productStore,
    IDataStoreClient dataStore,
    IOptions<SimulationOptions> options,
    TimeProvider time,
    ILogger<JobExecutor> logger) : IJobExecutor
{
    private readonly SimulationOptions _options = options.Value;

    public async Task ExecuteAsync(SimulationJob job, CancellationToken ct)
    {
        var log = await LoadLogAsync(job, ct);
        await InsertHeaderAsync(job, log, ct);

        var speed = job.Speed ?? 1;
        for (var loop = 1; loop <= job.LoopCount; loop++)
        {
            job.SetCurrentLoop(loop);
            logger.LogInformation("Job {JobId}: loop {Loop}/{LoopCount} started at {Speed}x", job.Id, loop, job.LoopCount, speed);

            DataPoint? previous = null;
            foreach (var point in log.Points)
            {
                ct.ThrowIfCancellationRequested();

                var delay = CalculateDelay(job.LogType, speed, point, previous);
                if (delay > TimeSpan.Zero) await Task.Delay(delay, time, ct);

                await dataStore.SendPointAsync(job.ChannelSetId!, point, ct);
                job.IncrementRowsSent();
                previous = point;
            }
        }

        logger.LogInformation("Job {JobId}: sent {Rows} rows", job.Id, job.RowsSent);
    }

    private async Task<ParsedLog> LoadLogAsync(SimulationJob job, CancellationToken ct)
    {
        await using var stream = storage.OpenRead(job.StoredFilePath);
        var outcome = await parsers.Get(job.Format).ParseAsync(stream, ct);

        return outcome.Log ?? throw new InvalidOperationException(
            "The stored file is no longer valid: " + string.Join(" ", outcome.StructureErrors.Concat(outcome.LogTypeErrors).Take(3)));
    }

    /// <summary>Creates well, wellbore, channel set and channels. Skipped when the job is run again.</summary>
    private async Task InsertHeaderAsync(SimulationJob job, ParsedLog log, CancellationToken ct)
    {
        if (job.ChannelSetId is not null) return;

        job.WellId ??= await productStore.CreateWellAsync(new WellHeader(job.WellName, job.WellUid), ct);
        job.WellboreId ??= await productStore.CreateWellboreAsync(job.WellId, new WellboreHeader(job.WellboreName, job.WellboreUid), ct);

        var logHeader = new LogHeader(job.LogName, job.LogUid, job.LogType, job.IndexMnemonic, job.IndexUnit,
            job.StartIndex, job.EndIndex, job.Format, job.FileName);
        var channelSetId = await productStore.CreateChannelSetAsync(job.WellboreId, logHeader, ct);

        foreach (var channel in log.Channels)
            await productStore.CreateChannelAsync(channelSetId, new ChannelHeader(channel.Mnemonic, channel.Unit, channel.Description), ct);

        // Set last so a failure half-way through recreates the channel set on retry.
        job.ChannelSetId = channelSetId;
        repository.Save(job);   // so a restart doesn't create the well/log again
        logger.LogInformation("Job {JobId}: header inserted (channel set {ChannelSetId}, {Channels} channels)",
            job.Id, channelSetId, log.Channels.Count);
    }

    /// <summary>
    /// Time logs: wait the real gap between the two rows divided by the speed (capped by MaxRowDelayMs).
    /// Depth logs: wait DepthRowIntervalMs divided by the speed.
    /// </summary>
    private TimeSpan CalculateDelay(LogType logType, int speed, DataPoint current, DataPoint? previous)
    {
        if (previous is null) return TimeSpan.Zero;

        double ms = logType switch
        {
            LogType.Time when current.Time.HasValue && previous.Time.HasValue =>
                (current.Time.Value - previous.Time.Value).TotalMilliseconds / speed,
            LogType.Depth => (double)_options.DepthRowIntervalMs / speed,
            _ => 0
        };

        return TimeSpan.FromMilliseconds(Math.Clamp(ms, 0, _options.MaxRowDelayMs));
    }
}
